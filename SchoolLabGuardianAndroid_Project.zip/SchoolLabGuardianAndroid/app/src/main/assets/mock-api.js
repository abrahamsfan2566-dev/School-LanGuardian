// Local offline simulation layer for the Android APK.
const LocalGuardian = (() => {
  let state = {mode:"demo",threshold_ms:120,loss_threshold:5,auto_repair:true,policy:"طبيعي",repair_count:0,history:[],alerts:[],events:[],simulated_load:false};
  const stamp=()=>new Date().toLocaleString("ar-EG");
  const health=m=>Math.max(0,Math.min(100,100-(m.latency_ms>120?35:m.latency_ms>70?15:0)-Math.min(50,Math.floor((m.packet_loss_pct||0)*5))-(m.utilization_pct>90?25:m.utilization_pct>75?10:0)));
  function sample(){
    const load=state.simulated_load;
    const m={timestamp:stamp(),latency_ms:+(load?165+Math.random()*95:18+Math.random()*30).toFixed(1),
      packet_loss_pct:load?[0,0,1,2,8][Math.floor(Math.random()*5)]:[0,0,0,0,1][Math.floor(Math.random()*5)],
      utilization_pct:load?82+Math.floor(Math.random()*18):12+Math.floor(Math.random()*37),
      jitter_ms:+(load?35+Math.random()*40:2+Math.random()*13).toFixed(1),
      throughput_mbps:+(load ? .4+Math.random()*1.6 : 12+Math.random()*36).toFixed(1),source:"محاكاة"};
    m.health_score=health(m); state.history.push(m); state.history=state.history.slice(-600);
    const issues=[];
    if(m.latency_ms>state.threshold_ms)issues.push("زمن الاستجابة أعلى من الحد");
    if(m.packet_loss_pct>=state.loss_threshold)issues.push("فقدان حزم مرتفع");
    if(m.utilization_pct>=90)issues.push("استهلاك الشبكة مرتفع");
    if(issues.length){state.alerts.unshift({timestamp:m.timestamp,severity:issues.length>1?"مرتفع":"متوسط",message:issues.join("؛ "),status:state.auto_repair?"تم الإصلاح التجريبي":"يحتاج مراجعة"});state.alerts=state.alerts.slice(0,100);
      if(state.auto_repair){state.policy="أولوية للخدمات المهمة + تحديد حمل الطلاب (محاكاة)";state.repair_count++;state.events.unshift({timestamp:m.timestamp,action:"تطبيق سياسة QoS تجريبية",result:"محاكاة فقط — لم يتم تغيير إعدادات راوتر حقيقي"});}
    } else state.policy="طبيعي";
    return m;
  }
  function status(){return {mode:state.mode,threshold_ms:state.threshold_ms,loss_threshold:state.loss_threshold,auto_repair:state.auto_repair,policy:state.policy,repair_count:state.repair_count,history:state.history.slice(-60),alerts:state.alerts.slice(0,20),events:state.events.slice(0,10),simulated_load:state.simulated_load,psutil_available:false};}
  async function api(url,options={}){
    const data=options.body?JSON.parse(options.body):{};
    if(url==="/api/status")return status();
    if(url==="/api/sample"){return sample();}
    if(url==="/api/settings"){if(["demo","real"].includes(data.mode))state.mode=data.mode;state.mode="demo";if("auto_repair"in data)state.auto_repair=!!data.auto_repair;if("threshold_ms"in data)state.threshold_ms=Math.max(20,Math.min(1000,Number(data.threshold_ms)||120));return {ok:true};}
    if(url==="/api/load"){state.simulated_load=!!data.enabled;return {ok:true};}
    if(url==="/api/clear"){state.history=[];state.alerts=[];state.events=[];state.repair_count=0;return {ok:true};}
    throw new Error("الوظيفة غير متاحة في النسخة المستقلة");
  }
  function exportCsv(){
    const fields=["timestamp","source","latency_ms","jitter_ms","packet_loss_pct","utilization_pct","throughput_mbps","health_score"];
    const rows=[fields.join(","),...state.history.map(r=>fields.map(k=>'"'+String(r[k]??"").replace(/"/g,'""')+'"').join(","))];
    const blob=new Blob(["\ufeff"+rows.join("\r\n")],{type:"text/csv;charset=utf-8"});
    const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="school_lab_guardian_metrics.csv";a.click();URL.revokeObjectURL(a.href);
  }
  return {api,exportCsv};
})();
window.api=LocalGuardian.api;
