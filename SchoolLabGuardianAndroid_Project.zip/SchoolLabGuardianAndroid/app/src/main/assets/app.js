const $ = id => document.getElementById(id);
let statusData = null;
const fmt = v => v === null || v === undefined ? "—" : v;
async function api(url, options={}) { return window.api(url, options); }
function drawChart(history) {
  const canvas = $("chart"), ctx = canvas.getContext("2d");
  const rect = canvas.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
  canvas.width = Math.max(1, rect.width*dpr); canvas.height = Math.max(1, rect.height*dpr);
  ctx.scale(dpr,dpr);
  const w=rect.width,h=rect.height,pad={l:32,r:12,t:15,b:24};
  ctx.clearRect(0,0,w,h);
  const rows=history.slice(-30), vals=rows.map(x=>x.latency_ms).filter(x=>x!==null && x!==undefined);
  const max=Math.max(150,...vals), min=0;
  ctx.font="10px Arial"; ctx.strokeStyle="#e8edf5";ctx.fillStyle="#8190a5";ctx.lineWidth=1;
  for(let i=0;i<4;i++){let y=pad.t+(h-pad.t-pad.b)*i/3;ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(w-pad.r,y);ctx.stroke();ctx.fillText(Math.round(max*(1-i/3)),2,y+3)}
  if(rows.length<2)return;
  const cw=w-pad.l-pad.r,ch=h-pad.t-pad.b;
  ctx.strokeStyle="#3568e8";ctx.lineWidth=2.5;ctx.lineJoin="round";ctx.beginPath();
  let started=false;
  rows.forEach((r,i)=>{if(r.latency_ms==null)return;let x=pad.l+cw*i/(rows.length-1),y=pad.t+ch*(1-r.latency_ms/max);if(!started){ctx.moveTo(x,y);started=true}else ctx.lineTo(x,y)});
  ctx.stroke();
  const threshold=Number($("threshold").value||120), ty=pad.t+ch*(1-threshold/max);
  ctx.setLineDash([5,4]);ctx.strokeStyle="#e49a28";ctx.beginPath();ctx.moveTo(pad.l,ty);ctx.lineTo(w-pad.r,ty);ctx.stroke();ctx.setLineDash([]);
}
function renderAlerts(alerts){
  $("alertCount").textContent=`${alerts.length} تنبيه`;
  const el=$("alerts");
  if(!alerts.length){el.className="alerts empty";el.textContent="لا توجد تنبيهات. ابدأ القياس أو فعّل محاكاة الضغط.";return}
  el.className="alerts";el.innerHTML=alerts.map(a=>`<div class="alert-item"><div><strong>${escapeHtml(a.message)}</strong><small>${escapeHtml(a.timestamp)} • ${escapeHtml(a.status)}</small></div><span class="alert-tag">${escapeHtml(a.severity)}</span></div>`).join("");
}
function renderEvents(events){
  const el=$("events");
  if(!events.length){el.className="events empty";el.textContent="لا توجد إجراءات مسجلة.";return}
  el.className="events";el.innerHTML=events.map(e=>`<div class="event-item"><div><strong>${escapeHtml(e.action)}</strong><small>${escapeHtml(e.timestamp)} • ${escapeHtml(e.result)}</small></div><span class="event-tag">مسجل</span></div>`).join("");
}
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function renderStatus(s){
  statusData=s;
  $("mode").value=s.mode;$("modeBadge").textContent=s.mode==="demo"?"وضع المحاكاة":"قياس حقيقي محدود";
  $("autoRepair").checked=s.auto_repair;$("threshold").value=s.threshold_ms;
  $("policy").textContent=s.policy;$("repairCount").textContent=s.repair_count;
  $("loadState").textContent=s.simulated_load?"ضغط محاكاة":"طبيعي";
  $("repairDesc").textContent=s.mode==="demo"?"الإجراءات المسجلة لا تغيّر جهازًا حقيقيًا": "لا يوجد تحكم فعلي في الراوتر";
  const last=s.history[s.history.length-1];
  if(last){
    $("health").textContent=last.health_score;$("healthBar").style.width=last.health_score+"%";
    $("healthBar").style.background=last.health_score<50?"#e45c5c":last.health_score<75?"#e6a23c":"#179b75";
    $("healthText").textContent=last.health_score>=80?"حالة جيدة":last.health_score>=50?"تحتاج متابعة":"حالة متدهورة";
    $("latency").textContent=fmt(last.latency_ms);$("loss").textContent=fmt(last.packet_loss_pct);
    $("throughput").textContent=fmt(last.throughput_mbps);
    $("throughputNote").textContent=last.source==="محاكاة"?"قيمة تجريبية وليست قياسًا فعليًا":"معدل نقل تقريبي من الجهاز";
    $("lastUpdated").textContent="آخر قياس: "+last.timestamp;
  }
  $("connectionLabel").textContent="النظام يعمل";
  drawChart(s.history);renderAlerts(s.alerts);renderEvents(s.events);
}
async function takeSample(){
  $("sampleBtn").disabled=true;$("connectionLabel").textContent="جارٍ القياس…";
  try{await api("/api/sample",{method:"POST",body:JSON.stringify({})});await refresh()}
  catch(e){$("connectionLabel").textContent=e.message}
  finally{$("sampleBtn").disabled=false}
}
async function refresh(){try{renderStatus(await api("/api/status"))}catch(e){$("connectionLabel").textContent="تعذر الاتصال بالخادم"}}
$("sampleBtn").addEventListener("click",takeSample);
$("saveSettings").addEventListener("click",async()=>{
  try{await api("/api/settings",{method:"POST",body:JSON.stringify({mode:$("mode").value,threshold_ms:Number($("threshold").value),auto_repair:$("autoRepair").checked})});await refresh();await takeSample()}
  catch(e){alert(e.message)}
});
$("loadBtn").addEventListener("click",async()=>{await api("/api/load",{method:"POST",body:JSON.stringify({enabled:true})});await takeSample()});
$("normalBtn").addEventListener("click",async()=>{await api("/api/load",{method:"POST",body:JSON.stringify({enabled:false})});await takeSample()});
window.addEventListener("resize",()=>{if(statusData)drawChart(statusData.history)});
refresh();
takeSample();
setInterval(async()=>{if(statusData?.mode==="demo")await takeSample()},10000);

document.getElementById("exportBtn")?.addEventListener("click",()=>LocalGuardian.exportCsv());
